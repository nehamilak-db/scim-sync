# Azure AAD to Databricks Account SCIM Sync

An example of end to end synchronization of the whitelisted Azure Active Directory groups and their members into the Databricks Account.

This python based application supports synchronization of Groups and their members - Users and Service Principals. 
- Note: - As per https://learn.microsoft.com/en-us/graph/api/group-list-members?view=graph-rest-1.0&tabs=http, current Microsoft Group Member API has known issues with Service Principal as group-member, and suggestion is to use BETA version instead, which is used in this implementation. Once Microsoft provides the GA version, update to use GA version APIs. 

- Note: - For UBS, users are represented by their UPN in both Entra ID and DB account, and UPN/email in entra id can be different. 

Synchronization principles:

- When doing synchronization no security principals (users, service principals or groups) are ever deleted.
- Synchronization only adds new security principals, or updates their attributes (like display name, or active flag) of already existing ones.
- Group members are fully sychronized to match what is present in AAD. Any new groups members are automatically added to databricks account.
- By default incremental/change feed is used, hence only AAD/Entra groups that have changed since last runare being synced to Databricks! This reduces reduces synchronization time dramatically.
- When incremental is used for a first time, the full sync is performed, consequitve runs will be just incrementals.

## Full synchronization (`--full-sync`)

Synchronizes all provided groups in the `--groups-json-file <file>`, without using change feed. The list of groups for syncing can vary from one run to other, hence it's possible to just selectively sync few groups at a time, or run sync of all the groups in scope of your application. It goes without saying that sync of 5 groups (and their members) will take few seconds, while syncing of all users, service principals, and groups, can take tens of minutes/hours.

To run the full sync, follow [Incremental synchronization](#incremental-synchronization-default), and add `--full-sync` patameter to force full synchronization.

When --full-sync is executed without `--groups-json-file <file>`, it will try to find and sync groups that are already synced to DB account (and thus are in cache_group.json). If cache file is not present, the processing will exit with an error, indicating absence of group information.

Reasons why --full-sync is recommended: 
- Incremental sync only captures changes made in AAD/Entra side, due to this any changes to group membership made directly in the Databricks Account won't be detected till next time group changes in AAD/Entra.
- Limitations of incremental mode (see below)

## Incremental synchronization (default)

Uses [Graph API change feed](https://learn.microsoft.com/en-us/graph/api/resources/change-notifications-api-overview?view=graph-rest-1.0) to determine the [groups that have changed](https://learn.microsoft.com/en-us/graph/api/group-delta?view=graph-rest-1.0&tabs=http#query-parameters) since last run. In this mode, all previously synchronized groups will be checked for changes. That means that groups that changed in AAD/Entra, but never were requested to be synced will be ignored.

In scenario where incremental sync is ran for specific group(s) for the first time, the full synchronization of specific groups(s) is automatically performed in order to capture all the memembers of a group.

Hence this default mode is handing both situation where initial sync needs to be done, or consequtive groups changes needs to be synced.

To run the incremental sync follow these steps:

- Authenticate: [Authentication steps described in section below](#authentication)
- (Optionally) For the first run, create `json` file containing the list of AAD groups names you would like to add to sync, and save it to `groups_to_sync.json` (for reference, see `examples/groups_to_sync.json`). 
- Run sync with dry run first: `azure_dbr_scim_sync --dry-run-security-principals --dry-run-members`.
  - (optionally) add `--groups-json-file groups_to_sync.json` to use the file with groups, consequtive runs don't need this file anymore.
- To get more information about the process:
  - `--verbose` (display groups to be synced, new grups for full sync, also logs information also about identities that did not change, by default only changes are logged)
  - or `--debug` (very detail, incl. api calls)
- Follow the prompts on the screen with regards to how to proceed with the [dry run](#dry-run-sync) levels.
  - If suggested list of changes look like what you would expect run without `--dry-run...` parameter(s)
- Repeat the steps again, but on bigger list of groups by adding more groups to `groups_to_sync.json`.
Some technical facts:

- Internally all cached groups (contents of `cache_groups.json`) are used to determine the names of groups for syncing.
- When optional `--groups-json-file <file>` parameter is provided, any new groups defined will be fully synced on a first run. Groups that are already in cache wont have any significance, hence it's allowed to execute command perpectually with the same file, and it will have no effect on consequtive runs.
- Graph API incremental token is saved in `graph_incremental_token.json` file after each successfull sync. Deleting this file will cause full sync again, as if the incremental mode was ran for the first time.

Limitations:

- Change data feed desynchronization can happen on Graph API side. It's possible to get information from change feed that groups members have changed, but the API reposponsible for group membership will not see the changes yet. This is rare. To make sure this happens as rare as possible, by default graph membership check logic waits 30 (seconds) before making any membership check related API queries.
- [Users change feed](https://learn.microsoft.com/en-us/graph/api/resources/user?view=graph-rest-1.0) is not implemented yet. As a consequence changes to users who are not a part of a group will not be detected. This will yield issues in situations:
  - When user gets deactived/deleted in AAD/Entra and imediately removed from all the groups. As result sync will just detect that user is not member of any groups anymore, and remove the membership but it will never deactive the account because user is not synced. If user would be kept in one or more groups, then user account would be correctly deactived.
  - When user would be just deactived without changing membership, it would then be not synced till next time group membership changes due to other user being added/removed, which in turn would cause a group sync, and user account would be deactived correctly.


## Mixed Sync

It is allowed to switch between incremental and full synchronization modes at will, for example there are two usecases/patterns I have observed:

- Full sync of newly to be onboarded groups, usually of adhoc nature, always needed when onboarding a new team to Unity Catalog. Normally you would like to sync all team groups and their members before running the onboarding process. This way that all the access could be set by your CI/CD automation (looking at you here [databricks terraform provider](https://registry.terraform.io/providers/databricks/databricks/latest/docs)). Without doing this step automation would most likely fail because the groups or other identities would not be yet presentin databricks account.
- Incremental sync, running on a schedule every few hours/minutes, that will be synchronizing all previously synced groups.

The interface to faciciliate these two usecases is the same, the only difference are:

- full sync required `--full-sync` parameter, while incremental require its absence.
- the list of groups:
  - full sync uses the provided groups `--groups-json-file <file>`
  - while incremental uses list of previously synced groups, if `--groups-json-file <file>` is provided, the new groups will be handled as if they were fully synced
- trigger:
  - full sync, due to performance reasons should be in adhoc nature.
  - incremental sync, due to being fast, should be run on a schedule basis (every 30 minutes or every 1h).

Reference of command line:

```shell
$ ✗ azure_dbr_scim_sync --help
Usage: azure_dbr_scim_sync [OPTIONS]

Options:
  --groups-json-file TEXT         list of AAD groups to add to sync (json
                                  formatted)
  --verbose                       verbose information about changes
  --debug                         more verbose, shows API calls
  --dry-run-security-principals   dont make any changes to users, groups or
                                  service principals, just display pending
                                  changes
  --dry-run-members               dont make any changes to group members, just
                                  display pending membership changes
  --worker-threads INTEGER        number of concurent web requests to perform
                                  against SCIM  [default: 10]
  --graph-change-feed-grace-time INTEGER
                                  time in seconds to wait before checking
                                  membership of groups detected in incremental
                                  mode  [default: 30]
  --full-sync                     synchronizes all groups defined in `groups-
                                  json-file` instead of using graph api change
                                  feed
  --help                          Show this message and exit.
```

### Dry run sync

The sync tool offers two dry run modes, allowing to first see, and then approve changes:

- `--dry-run-security-principals`: allows to see which users, service principals and groups (not members!) would be added, or changed. At this point, if any changes are present the group membership synchronization will be skipped, and only can be continued once changes are applied.
- `--dry-run-members`: applies any pending changes from above, and displays any group members that would be added or removed. In order to apply group members changes, run without any dry run modes.

## Authentication

Sync tool needs authentication in order to connect to **AAD**, **Azure Databricks Account**, and **Azure Datalake Storage Gen2** for cache purpose.

It's highly recommended to first trying running the tool from your local user account, directly from your laptop/pc/mac/rasperypi :) and once it works switch over to devops and there run it as service principal. 

The authentication is decoupled from the sync logic, hence it's possible to change way of authentication (user vs. service principal auth) via change of enviroment settings/variables without need of changing any code. Please read more about it in respective sections below.

Please refer to the user guide for more details on Authentication. 

## Building a package / Local development

Currently package for this code is not being distributed, you need to build it yourself, follow these steps to do so:

- run `make dev` (will put you in `.venv`)
- run `make dist`
- in `dist` folder package placed will be
- run `make install` to install the package locally
- if you are in `.venv`, you should be able to run `azure_dbr_scim_sync --help`
- if you are not in `.venv` follow on screen instructions regarding placement of the CLI command

## Limitations

- Inactive AAD Users and Service Principals are only inactivated in Databricks Account when they are being synced, as in being member of the group that is being synced. For example, if dis-activated user gets also removed from the groups, then this user wont be taking part of sync anymore, and due to this this user wont be deactivated in Databricks Account.
  - Workaround for this is to disable User or Service Princial in AAD and keep them as members of groups they used to be in. This way next full sync will disable them in account console.

## Near time roadmap

- Implement Individual SPN Sync that aren't part of any group
- Implement user deletion (for leavers)
